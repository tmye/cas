<?php
// G�n�ration du fichier de d�finition de police pour le tutoriel 7
require('../makefont/makefont.php');

MakeFont('calligra.ttf','cp1252');
?>
