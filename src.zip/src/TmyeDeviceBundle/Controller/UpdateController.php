<?php

namespace TmyeDeviceBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class UpdateController extends Controller
{

    /* a controller for updating the machines

        - send actions ---
        - send device id --- ;;; get what it is to get in the database
            // and do what there is do.
        - save the json content that we have to send directly in the database,
            - especially for
        - get update entities for each type //

     */


}
