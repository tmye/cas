<?php

namespace TmyeDeviceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TmyeDeviceBundle extends Bundle
{
}
