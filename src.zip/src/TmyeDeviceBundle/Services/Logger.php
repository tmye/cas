<?php
/**
 * Created by PhpStorm.
 * User: abiguime
 * Date: 13/02/2017
 * Time: 6:11 PM
 */

namespace TmyeDeviceBundle\Services;


class Logger
{


}



?>